$('.hamburger-icon').on('click', function(e){
	e.preventDefault();
	$(this).toggleClass('active');
});
