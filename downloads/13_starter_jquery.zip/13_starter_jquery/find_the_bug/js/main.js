Here's my jQuery

$('h1').addClass('.my-class');

('projects').on('click', function () {
  $('body')hide('h1');

});

