// PART 1 - Functions review
// 1. Write a function and name it addMagic
	// Inside the function, log "Magic!" to the console using console.log()

// 2. Call the addMagic function to make sure it works


// PART 2 - see index.html line 30


// PART 3 - jQuery click event listener
// Add an event listener to the button with the id 'magic'
// So when the 'magic' button is clicked, it calls the addMagic function


// PART 4 - Using jQuery to work with elements
// Use jQuery to add the 'special' class to the li element with the text 'Having a blast!'


// PART 5 - Using jQuery animations
// Use jQuery to set the src attribute of the img element in the html to
// the fun.jpg file in the images folder
// Then use jQuery to fade the img in
