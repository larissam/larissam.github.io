var globalVariable = "Police";

function interrogationRoom () {
  console.log('inside room');
  var localVariable = "Suspect";
  
}

console.log(globalVariable);

// This line will create an error - open up your developer tools to see it
// console.log(localVariable);

interrogationRoom();