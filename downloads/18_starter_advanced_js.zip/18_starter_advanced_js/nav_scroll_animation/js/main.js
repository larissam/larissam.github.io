// Smooth scroll this mother!

// Do it when someone clicks a nav link
$('nav a').on('click', function(e) {
  // prevent the standard link operation on click
  e.preventDefault();

  // use the href of the link to identify what
  // section to scroll to
  var thisTarget = $(this).attr('href');

  // get that section's top offset
  var targetOffset = $(thisTarget).offset().top;

  // use jQuery.animate() to animate the body's
  // scrollTop to the targetOffset
  $('html, body').animate({
    scrollTop: targetOffset
  }, 600);
});
