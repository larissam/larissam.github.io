// PART 3

// WHEN the user clicks the button
// Replace 'yourSelectorHere' with your button selector
// Replace 'eventHere' with your event
$('yourSelectorHere').on('eventHere', function() {
    // Add the animate class to the bugs!

});
