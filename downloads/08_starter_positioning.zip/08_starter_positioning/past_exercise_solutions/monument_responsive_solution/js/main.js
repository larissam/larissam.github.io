// Write your pseudo code here!

// When the user clicks the hamburger icon
	// Slide toggle the ul