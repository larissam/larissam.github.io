$('#showModal').on('click', function(){
	$('.modal').css('display', 'flex').hide().fadeIn();

	// prevents the user from scrolling in the background
	$('body').css('overflow', 'hidden');
});

$('#close').on('click', function(){
	$('.modal').fadeOut();

	// allows the user to scroll the background again
	$('body').css('overflow', 'auto');
});


