// when you click on an img in the gallery,
// make the modal img show the same src as the gallery img you clicked
$('.gallery img').on('click', function(){
	$('.modal').css('display', 'flex').hide().fadeIn();

	var clickedImgElement = $(this);
	var clickedImgElementSrc = clickedImgElement.attr('src');
	$('.modal img').attr('src', clickedImgElementSrc);

	// lines 6-8 are equivalent to:
	// $('.modal img').attr('src', $(this).attr('src'));

	$('body').css('overflow', 'hidden');
});

// click anywhere on the modal to make it close
$('.modal').on('click', function(){
	$(this).fadeOut();

	$('body').css('overflow', 'auto');
});