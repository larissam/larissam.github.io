// 1. Create a variable indexNumber and give it a value of 0

// 2. Create an array motivationalQuotes. It should store the following 3 strings:
// "You can do it!"
// "You're a JavaScript Ninja"
// "Keep going!"


// This setInterval will run every 3 seconds:
setInterval(function () {
	// If the indexNumber is less than 2
		// Add one to the indexNumber variable using +=
	// Else
		// Set the indexNumber variable to 0

	// Update the text of .quote to the quote at the current index number


}, 3000);