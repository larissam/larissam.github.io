
var isGameStarted = false;
var actions = ['rock', 'paper', 'scissors'];

var humanScore = 0;
var computerScore = 0;

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);

  return Math.floor(Math.random()*(max - min)) + min;
}

function getComputerPlay(){
  return actions[getRandomInt(0, 3)];
}

function startGame(){
  $('#scoreboard').addClass('show');
}

function play(humanPlay, computerPlay) {
  $('#humanPlay').text(humanPlay);
  $('#computerPlay').text(computerPlay);

  if(humanPlay === computerPlay){
    $('#result').text('You tied. :|');
  } else if (humanPlay === 'paper' && computerPlay === 'rock' ||
             humanPlay === 'rock' && computerPlay === 'scissors' ||
             humanPlay === 'scissors' && computerPlay === 'paper') {
    $('#result').text('You win! :)');
    humanScore += 1;
  } else {
    $('#result').text('You lose! :(');
    computerScore += 1;
  }

  $('#humanScore').text(humanScore);
  $('#computerScore').text(computerScore);
}


$('.game-button').on('click', function(){
  if(!isGameStarted) {
    startGame();
  }

  var action = $(this).data('action');
  play(action, getComputerPlay());
});