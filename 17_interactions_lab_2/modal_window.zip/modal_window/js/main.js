$('#showModal').on('click', function(){
	$('body').addClass('open');
});

$('#close').on('click', function(){
	$('body').removeClass('open');
})