// PART 3
// Make the bugs animate when you click the button!
$('button').on('click', function(){
	$('.bug').addClass('animate');
})